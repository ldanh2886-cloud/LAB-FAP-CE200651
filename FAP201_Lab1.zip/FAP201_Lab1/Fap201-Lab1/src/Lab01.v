module Lab01 (
    input  wire i_clk,
    input  wire i_sw1,
    input  wire i_sw2,
    input  wire i_sw3,

    output reg  o_led1,
    output reg  o_led2,
    output reg  o_led3
);

    reg [24:0] counter = 0;
    reg [1:0]  state = 0;

    always @(posedge i_clk) begin
        if (counter >= 25'd24_999_999) begin
            counter <= 0;

            if (state == 2)
                state <= 0;
            else
                state <= state + 1'b1;
        end
        else begin
            counter <= counter + 1'b1;
        end
    end

    always @(*) begin
        o_led1 = 0;
        o_led2 = 0;
        o_led3 = 0;

        case (state)
            0: o_led1 = 1;
            1: o_led2 = 1;
            2: o_led3 = 1;
            default: begin
                o_led1 = 0;
                o_led2 = 0;
                o_led3 = 0;
            end
        endcase
    end

endmodule