`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
dMQ32v6siUwXE3omzJAD6JZzStRACbcF5sYmrebV/Ewv3zEEuZoPOqIHd5zgb83mPii1SzolAvJg
xPA8OKSf+yRVX7CsTHPRPfheSvhvCDbbxRsK6QrPu1FrzcuBs7+q6OONbnsbEdISmt41mC9GHvQ7
p1UB3sqogGLTiok8/y2gkE+v6MMVOPsS4MmYV3AiHfZOywkrGpLvgAg23GaWDzAhTTKtEn1Iec9L
om6CJSe8ROFGArYpR9yG7tWUxxrSlNeijecz7cdwg015BKN1aSQV3KlH1sd+XR3JZ3pvFztM5vsx
O7Ne+9Jxpv5Vjb+q6gAApH8QvMOfUk05No70SA==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=368)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
DZt7L0bYTloheRopXBC6WrMxAcFolNNw2DU56YET19GZh1/E21Symrm1Umzf4DQxOQCJzvLbuEYW
3iQjfOHuYKEqT5Q7Ib1NuCT4/3N3GS//TvWGwNvRnNmHiYT2JnXqJrgetzz4FvKcopurTpYZ297h
Yl3W/utGnNGckOhfOqTc421nityD1Q0NB2hfQjqPPisDUQRdJ4eoATnla1ksxBhqoE4Ll2BmF74l
0rwBQPgv1OYA9vjZAAxzDHmDJoqZUGHurt0bB19p6m4ResC7qosQdJeuSIPKrzcpxqISGtwcHz4i
WUp3UeyJ6HxBLgnWH+/CliT0XnGuGYdtmjrmzMego92ZgVPz9KWQ0hMoGOXs9DGxCxSGrv26L2vw
eS3HVTGwEIsNsgCj+zo4/n+4fTi0sJi1gouVIYlV9Kr0daMnI9u4uvlx4GZLSV3J+1mYoigE+KDf
qWzqEfgmD5zHokqUw1Jc31/7k9utI5+V+DI=
`pragma protect end_protected
